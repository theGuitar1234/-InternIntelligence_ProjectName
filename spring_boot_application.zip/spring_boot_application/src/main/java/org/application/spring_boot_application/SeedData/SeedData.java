package org.application.spring_boot_application.SeedData;

import org.application.spring_boot_application.Entities.Movie;
import org.application.spring_boot_application.Services.MovieService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class SeedData implements CommandLineRunner {

    private final MovieService movieService;

    public SeedData(MovieService movieService) {
        this.movieService = movieService;
    }

    @Override
    public void run(String... args) throws Exception {
        Movie movie = new Movie();
        movie.setMovieTitleString("The GodFather");
        movie.setMovieDirectorString("Jon Smith");
        movie.setReleaseYear(1972);
        movie.setGenreString("Drama");
        movie.setIMDbRating(9.2);

        Movie movie2 = new Movie();
        movie2.setMovieTitleString("Rashawnk Redemption");
        movie2.setMovieDirectorString("Craig Mazin");
        movie2.setReleaseYear(2005);
        movie2.setGenreString("Drama");
        movie2.setIMDbRating(9.3);

        movieService.save(movie);
        movieService.save(movie2);
    }
    
}
