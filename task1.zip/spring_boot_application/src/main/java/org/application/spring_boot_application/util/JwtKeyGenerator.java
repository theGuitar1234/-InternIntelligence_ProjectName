package org.application.spring_boot_application.util;

import io.jsonwebtoken.Jwts;

import java.util.Base64;

import javax.crypto.SecretKey;

public class JwtKeyGenerator {

    public static void main(String[] args) {
        SecretKey secretKey = Jwts.SIG.HS256.key().build(); 
        String base64Key = Base64.getEncoder().encodeToString(
                                                    secretKey.getEncoded());
        System.out.println("JWT Public Key: " + base64Key);
    }

}
