package org.application.spring_boot_application.Repositories;

import java.util.Optional;

import org.application.spring_boot_application.Entities.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {
    Optional<Movie> findByMovieId(long movideId);
    void deleteByMovieId(long movieId);
} 