package org.application.spring_boot_application.util;

import java.util.Base64;
import java.util.Date;

import javax.crypto.SecretKey;

import org.application.spring_boot_application.util.constants.jwtkeys;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {
    
    private static final String JWT_KEY_STRING = jwtkeys.JWT_KEY.getJwtKeyString();

    private static final long EXPIRATION_DATE = 60*60*1000;

    private static SecretKey getSigningKey() {
	    byte[] keyBytes = Base64.getDecoder().decode(JWT_KEY_STRING);
	    return Keys.hmacShaKeyFor(keyBytes);
    }

    public String generateToken(String username) {
        return Jwts.builder()
                .subject(username)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + EXPIRATION_DATE))
                .signWith(getSigningKey(), Jwts.SIG.HS256)
                .compact();
    }

    public Claims validateToken(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token) 
                .getPayload(); 
    }  

}
