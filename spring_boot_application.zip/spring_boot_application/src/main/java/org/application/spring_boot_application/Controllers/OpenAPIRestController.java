package org.application.spring_boot_application.Controllers;

import org.springframework.web.bind.annotation.RestController;

import org.application.spring_boot_application.Entities.Movie;
import org.application.spring_boot_application.Services.MovieService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/index")
public class OpenAPIRestController {

    private final MovieService movieService;

    public OpenAPIRestController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping("/getMovieById")
    public ResponseEntity<Movie> getMovieById(long movieId) {
        Movie movie = movieService.getMovieByMovieId(movieId);
        return ResponseEntity.ok(movie);
    }
    
    @PostMapping("/createMovie")
    public ResponseEntity<String> createMovie(String movieTitleString, String movieDirectorString, int releaseYear, String genreString, double IMDbRatingString) {
        Movie movie = new Movie();
        movie.setMovieTitleString(movieTitleString);
        movie.setMovieDirectorString(movieDirectorString);
        movie.setReleaseYear(releaseYear);
        movie.setGenreString(genreString);
        movie.setIMDbRating(IMDbRatingString);

        movieService.save(movie);

        return ResponseEntity.status(HttpStatus.CREATED).body("Movie Saved : " + movie);
    }

    @PostMapping("/deleteMovieById")
    public ResponseEntity<String> deleteMovieById(long movieId) {
        movieService.deleteMovieByMovieId(movieId);
        return ResponseEntity.ok("Movie deleted by ID " + movieId);
    }  
    
    @PostMapping("/updateMovie")
    public ResponseEntity<String> updateMovieTitle(long id, String movieTitle) {
        movieService.updateMovieTitleString(id, movieTitle);
        return ResponseEntity.ok("Movie Title Updated : " + movieTitle);
    }
    
}
