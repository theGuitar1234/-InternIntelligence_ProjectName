package org.application.spring_boot_application.Entities;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.NoArgsConstructor;

@Entity
@Getter
@Setter
@ToString
@Component
@NoArgsConstructor
@Table(name="movies")
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long movieId;

    @Column(name = "movie_title")
    private String movieTitleString;
    
    @Column(name = "movie_director")
    private String movieDirectorString;

    @Column(name = "release_year")
    private int releaseYear;

    @Column(name = "movie_genre")
    private String genreString;

    @Column(name = "IMDb_rating")
    private double IMDbRating;

}
