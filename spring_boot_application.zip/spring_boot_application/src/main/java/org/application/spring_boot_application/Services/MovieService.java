package org.application.spring_boot_application.Services;

import java.util.Optional;

import org.application.spring_boot_application.Entities.Movie;
import org.application.spring_boot_application.Repositories.MovieRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MovieService {

    private final MovieRepository movieRepository;

    public MovieService(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }

    public void save(Movie movie) {
        movieRepository.save(movie);
    }

    public Movie getMovieByMovieId(long movideId) {
        Optional<Movie> movieOptional = movieRepository.findByMovieId(movideId);
        Movie movie = movieOptional.orElseThrow(() -> new RuntimeException("Movie not Found by " + movideId));
        return movie;
    }

    @Transactional //Transactional ensures database relationship, I use this for queries like delete and update operations
    public void deleteMovieByMovieId(long movieId) {
        movieRepository.deleteByMovieId(movieId);
    }

    @Transactional
    public void updateMovieTitleString(long movieId, String movieTitleString) {
        Optional<Movie> movieOptional = movieRepository.findByMovieId(movieId);
        Movie movie = movieOptional.orElseThrow(() -> new RuntimeException("Movie not found by the ID : " + movieId));
        movie.setMovieTitleString(movieTitleString);
    }
}